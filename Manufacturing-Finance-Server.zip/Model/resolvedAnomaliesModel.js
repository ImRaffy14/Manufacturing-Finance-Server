const mongoose = require('mongoose')

const schema = mongoose.Schema

const resolvedAnomaliesSchema = new schema({
    anomalyType: { type: String, required: true},
    dataId: { type: String },
    anomalyFrom: { type: String, required: true},
    description: { type: String },
    resolvedBy: { type: String },
    resolvedDate: { type: Date },
})

module.exports = mongoose.model('resolvedAnomlies', resolvedAnomaliesSchema)